#include "arvoreB.h"

noB* localiza_folha(int k, arv *tree)
{
    noB *aux = tree->raiz;
    no *auxL;
    noB *resp;

    if (tree->raiz == NULL)//arvore vazia mas que tem ordem definida
        resp = NULL; //indica que deve ser criada uma folha, a raiz
    else{

        while (aux->folha != 1) //criar funcao para verificar se � folha
        {
          if (k < aux->listaChaves->inicio->valor)
            aux = aux->esquerda;
          else
             auxL = aux->listaChaves->inicio;
             while (auxL != NULL && k > auxL->valor)
             {
              auxL = auxL->prox;
             }

             if(auxL == NULL)
                aux = aux->listaChaves->fim->filho;
             else
                aux = (noB*)auxL->ant->filho;
        }
        resp = aux;
    }
    return resp;
}

void insere_chave_no(int k, noB *folha)
{
    insere_ordenado(k,folha->listaChaves);
    folha->qtdChaves++;
}

noB* divide(noB* noCheio, int m)
{
    int meio=ceil(m/2.0);

    lista *listaNova;

    noB* novoNo= (noB*)malloc(sizeof(noB));

    listaNova = quebra_lista(noCheio->listaChaves, meio);

    novoNo->pai = noCheio->pai;
    novoNo->esquerda = NULL;
    novoNo->folha = noCheio->folha;
    novoNo->listaChaves = listaNova;
    novoNo->qtdChaves = m - meio;

    noCheio->qtdChaves = meio;
//e se o no que est� sendo dividido n�o for folha?



    return novoNo;
}






